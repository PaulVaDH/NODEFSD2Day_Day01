const Employee = require('../models/employee');
exports.getdefault = function(req, res){ 
  res.send('You are on the root route.'); 
};
//
exports.aboutus=function(req, res){
  res.send('You are on the about us route.');
};
//
exports.addemployee=function(req, res){
  let empName = req.body.empName;
  let empPass = req.body.empPass;
  //res.end(`POST success, you sent ${empName} and ${empPass}, thanks!`);
  const Emp = new Employee();
  Emp.empName = empName;
  Emp.empPass = empPass;
  Emp.save()
  .then(msg => {
    res.send({"message":"Created " + Emp.empName, "ID":msg._id});
  })
  .catch(
    err => res.send({"message":err.message})
  );
};
//
exports.getemployees=function(req, res){
  //res.send('You are on the getdocs route.');
  Employee.find({})
    .then(employeeData => {
      if(employeeData.length === 0)
        res.send({"message":"No Data!"});
      else
        res.send(employeeData);
      }
    )
    .catch(
      err => res.send(err)
    )

};
